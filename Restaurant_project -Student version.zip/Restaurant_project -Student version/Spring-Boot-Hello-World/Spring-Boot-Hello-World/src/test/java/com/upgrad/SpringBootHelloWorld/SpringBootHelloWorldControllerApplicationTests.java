package com.upgrad.SpringBootHelloWorld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootHelloWorldControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
